#!/bin/bash
gcc -m32 -g -o ekran glavni.c zad.S -lX11 -lpthread -lm

